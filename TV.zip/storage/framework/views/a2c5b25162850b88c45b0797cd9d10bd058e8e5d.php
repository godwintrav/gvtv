<html>
<h1>Login Page this is the login page</h1>
</html><?php /**PATH C:\xampp\htdocs\Laravel\blog\resources\views/login.blade.php ENDPATH**/ ?>