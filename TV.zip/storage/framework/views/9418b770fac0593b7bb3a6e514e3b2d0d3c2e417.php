

   <?php $__env->startSection('name', auth()->user()->firstname); ?>
   <?php $__env->startSection('playlist', 'active'); ?>

      <?php $__env->startSection('content'); ?>
         <div id="content-wrapper">
            <div class="container-fluid">
               <div class="video-block section-padding">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="main-title">
                           <div class="btn-group float-right right-action">
                              <a href="#" class="right-action-link text-gray" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Sort by <i class="fa fa-caret-down" aria-hidden="true"></i>
                              </a>
                              <div class="dropdown-menu dropdown-menu-right">
                                 <a class="dropdown-item" href="#"><i class="fas fa-fw fa-star"></i> &nbsp; Top Rated</a>
                                 <a class="dropdown-item" href="#"><i class="fas fa-fw fa-signal"></i> &nbsp; Viewed</a>
                                 <a class="dropdown-item" href="#"><i class="fas fa-fw fa-times-circle"></i> &nbsp; Close</a>
                              </div>
                           </div>
                           <h6>Playlist</h6>
                        </div>
                     </div>
                    <?php if(isset($medias) && $medias != null): ?>
                        <?php $__currentLoopData = $medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-3 col-sm-6 mb-3">
                                 <div class="video-card">
                                    <div class="video-card-image">
                                       <a class="video-close" href="" data-toggle="modal" data-target="#logoutModal<?php echo e($media->id, false); ?>"><i class="fas fa-times-circle"></i></a>
                                       <a class="play-icon" href="/viewer/ad/<?php echo e($media->id, false); ?>"><i class="fas fa-play-circle"></i></a>
                                       <a href="/viewer/ad/<?php echo e($media->id, false); ?>"><img class="img-fluid" src="<?php echo e(asset('storage/'.$media->thumbnail ?? ''), false); ?>" alt=""></a>
                                       <div class="time"></div>
                                    </div>
                                    <div class="video-card-body">
                                       <div class="video-title">
                                          <a href="/viewer/ad/<?php echo e($media->id, false); ?>"><?php echo e($media->title, false); ?></a>
                                       </div>
                                       <div class="video-page text-success">
                                          Aminaami Tv  <a title="" data-placement="top" data-toggle="tooltip" href="/viewer/ad/<?php echo e($media->id, false); ?>" data-original-title="Verified"><i class="fas fa-check-circle text-success"></i></a>
                                       </div>
                                       <div class="video-view">
                                       <?php echo e(count(json_decode($media->views)), false); ?> views &nbsp;<i class="fas fa-calendar-alt"></i> <?php echo e($media->created_at->format('M d Y') ?? '', false); ?>

                                       </div>
                                    </div>
                                 </div>

                                 <div class="modal fade" id="logoutModal<?php echo e($media->id, false); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                 <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                       <div class="modal-header">
                                          <h5 class="modal-title" id="exampleModalLabel">Delete Video <?php echo e($media->title, false); ?>?</h5>
                                          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                          <span aria-hidden="true">×</span>
                                          </button>
                                       </div>
                                       <div class="modal-body">Are you sure you want to delete this video from your playlist?</div>
                                       <div class="modal-footer">
                                          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                                          <a class="btn btn-primary" href="/viewer/delete_media/<?php echo e($media->id, false); ?>">Delete</a>
                                          </div>
                                       </div>
                                    </div>
                                 </div>

                              </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                    <?php else: ?>
                        <?php echo e($err_msg ?? '', false); ?>

                    <?php endif; ?>
                     
                  </div>
                  
               </div>
            </div>
            <!-- /.container-fluid -->
            <!-- Sticky Footer -->
         </div>
         <!-- /.content-wrapper -->
      </div>
      <!-- /#wrapper -->
      <!-- Scroll to Top Button-->
      <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
      </a>
      <!-- Logout Modal-->
      <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
         <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                  <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">×</span>
                  </button>
               </div>
               <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
               <div class="modal-footer">
                  <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                  <a class="btn btn-primary" href="/viewer/logout">Logout</a>
               </div>
            </div>
         </div>
      </div>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('viewer.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\TV\resources\views/viewer/playlist.blade.php ENDPATH**/ ?>