<html>
<h1>Greeting Screen</h1>
</html><?php /**PATH C:\xampp\htdocs\Laravel\blog\resources\views/greeting.blade.php ENDPATH**/ ?>